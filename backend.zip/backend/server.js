// backend/server.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const usersFile = path.join(__dirname, 'users.json');

// Rota de login (POST)
app.post('/login', (req, res) => {
  const { email, senha } = req.body;
  const users = JSON.parse(fs.readFileSync(usersFile, 'utf-8'));

  const user = users.find(u => u.email === email && u.senha === senha);
  if (user) {
    res.status(200).json({ success: true });
  } else {
    res.status(401).json({ success: false, message: "Usuário ou senha inválidos" });
  }
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
